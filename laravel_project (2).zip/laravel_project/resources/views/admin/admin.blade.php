<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin dashboard</title>
</head>
<body style="font-family:system-ui;margin:20px">
  <h1>Admin dashboard</h1>

  <ul>
    <li><a href="/admin/vacancies">Vacatures beheren</a></li>
    <li><a href="/admin/contact-messages">Contact berichten</a></li>
  </ul>
</body>
</html>
